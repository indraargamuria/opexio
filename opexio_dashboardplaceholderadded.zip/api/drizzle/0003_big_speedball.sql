ALTER TABLE `customers` ADD `emailAddress` text;--> statement-breakpoint
ALTER TABLE `customers` ADD `createdBy` text;--> statement-breakpoint
ALTER TABLE `shipmentHeader` ADD `createdBy` text;